# Node Blog API

A NodeJS REST API using Express, Mongoose and JWT authentication.

Role based authenticated is implemented with admin role being able to read, write, update and delete posts and user role being able to read posts and write comments only.

Testing with Mocha, Supertest and Expect.

### Getting started

git clone `https://github.com/adamokasha/node-blog-api.git`
